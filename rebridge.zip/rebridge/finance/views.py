from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Q
from django.shortcuts import render
from .models import LedgerEntry, Income, Expense, Advance
from properties.models import Property


@login_required
def ledger_view(request):
    """Property-wise ledger with totals."""
    property_id = request.GET.get("property")
    entries, totals = _ledger_data(property_id)
    return render(
        request,
        "finance/ledger.html",
        {
            "entries": entries,
            "totals": totals,
            "properties": Property.objects.all(),
            "property_id": property_id,
        },
    )


@login_required
def ledger_partial(request):
    """HTMX fragment for live-updating ledger."""
    property_id = request.GET.get("property")
    entries, totals = _ledger_data(property_id)
    return render(
        request,
        "finance/_ledger_table.html",
        {"entries": entries, "totals": totals},
    )


@login_required
def reports(request):
    """Income/expense summaries with filters."""
    property_id = request.GET.get("property")
    start = request.GET.get("start")
    end = request.GET.get("end")
    income_qs = Income.objects.all()
    expense_qs = Expense.objects.all()
    if property_id:
        income_qs = income_qs.filter(property_id=property_id)
        expense_qs = expense_qs.filter(property_id=property_id)
    if start and end:
        income_qs = income_qs.filter(date__range=[start, end])
        expense_qs = expense_qs.filter(date__range=[start, end])
    income_total = income_qs.aggregate(total=Sum("amount"))["total"] or 0
    expense_total = expense_qs.aggregate(total=Sum("amount"))["total"] or 0
    return render(
        request,
        "finance/reports.html",
        {
            "properties": Property.objects.all(),
            "income_total": income_total,
            "expense_total": expense_total,
            "income": income_qs.order_by("-date")[:100],
            "expenses": expense_qs.order_by("-date")[:100],
        },
    )


def _ledger_data(property_id):
    qs = LedgerEntry.objects.all()
    if property_id:
        qs = qs.filter(property_id=property_id)
    entries = qs.order_by("-date", "-created_at")[:200]
    totals = qs.aggregate(
        debit=Sum("amount", filter=Q(entry_type=LedgerEntry.DEBIT)),
        credit=Sum("amount", filter=Q(entry_type=LedgerEntry.CREDIT)),
    )
    return entries, totals
