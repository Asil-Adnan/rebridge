from django.urls import path
from . import views

urlpatterns = [
    path("ledger/", views.ledger_view, name="ledger"),
    path("ledger/partial/", views.ledger_partial, name="ledger_partial"),
    path("reports/", views.reports, name="reports"),
]
