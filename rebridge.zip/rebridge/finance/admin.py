from django.contrib import admin
from .models import Advance, Expense, Income, LedgerEntry, Renewal


@admin.register(Advance)
class AdvanceAdmin(admin.ModelAdmin):
    list_display = ("property", "transaction_name", "amount", "date", "voucher_ref")
    list_filter = ("property",)


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ("property", "transaction_name", "expense_type", "amount", "date", "voucher_id")
    list_filter = ("property", "expense_type")


@admin.register(Income)
class IncomeAdmin(admin.ModelAdmin):
    list_display = ("property", "transaction_name", "customer", "amount", "date", "reference")
    list_filter = ("property",)


@admin.register(LedgerEntry)
class LedgerEntryAdmin(admin.ModelAdmin):
    list_display = ("property", "entry_type", "amount", "date", "source")
    list_filter = ("property", "entry_type")


@admin.register(Renewal)
class RenewalAdmin(admin.ModelAdmin):
    list_display = ("customer", "start_date", "end_date", "payment_method")
    list_filter = ("payment_method",)
