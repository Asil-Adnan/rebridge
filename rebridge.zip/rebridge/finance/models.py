from django.db import models
from properties.models import Property
from accounts.models import CustomerProfile
from core.models import TimeStampedModel


class Advance(TimeStampedModel):
    """Partial payments to property owner."""

    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name="advances")
    transaction_name = models.CharField(max_length=255, default="Advance")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    date = models.DateField()
    voucher_ref = models.CharField(max_length=100)
    notes = models.TextField(blank=True)

    def __str__(self) -> str:
        return f"Advance {self.voucher_ref} - {self.property.name}"


class Expense(TimeStampedModel):
    """Property-wise expenses."""

    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name="expenses")
    transaction_name = models.CharField(max_length=255, default="Expense")
    expense_type = models.CharField(max_length=120)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    date = models.DateField()
    voucher_id = models.CharField(max_length=100)
    attachment = models.FileField(upload_to="expense/", null=True, blank=True)

    def __str__(self) -> str:
        return f"Expense {self.voucher_id} - {self.property.name}"


class Income(TimeStampedModel):
    """Income records (e.g., renewals)."""

    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name="income")
    customer = models.ForeignKey(CustomerProfile, on_delete=models.SET_NULL, null=True, blank=True)
    transaction_name = models.CharField(max_length=255, default="Income")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    date = models.DateField()
    reference = models.CharField(max_length=100, blank=True)

    def __str__(self) -> str:
        return f"Income {self.reference or self.id} - {self.property.name}"


class LedgerEntry(TimeStampedModel):
    """Normalized ledger for debit/credit."""

    DEBIT = "DEBIT"
    CREDIT = "CREDIT"
    TYPE_CHOICES = [(DEBIT, "Debit"), (CREDIT, "Credit")]

    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name="ledger_entries")
    entry_type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    date = models.DateField()
    source = models.CharField(max_length=50)  # income/expense/advance
    reference_id = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)

    def __str__(self) -> str:
        return f"{self.entry_type} {self.amount} - {self.property.name}"


class Renewal(TimeStampedModel):
    """Renewal records for customers."""

    customer = models.ForeignKey(CustomerProfile, on_delete=models.CASCADE, related_name="renewals")
    start_date = models.DateField()
    end_date = models.DateField()
    payment_method = models.CharField(max_length=50, blank=True)

    def __str__(self) -> str:
        return f"Renewal {self.customer} {self.start_date} - {self.end_date}"
