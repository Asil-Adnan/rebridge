from django.contrib.auth.models import AbstractUser
from django.db import models
from core.models import Document, TimeStampedModel


class User(AbstractUser):
    """Custom user with role and mobile number."""

    ROLE_ADMIN = "ADMIN"
    ROLE_FINANCE = "FINANCE"
    ROLE_MANAGER = "MANAGER"
    ROLE_CUSTOMER = "CUSTOMER"
    ROLE_CHOICES = [
        (ROLE_ADMIN, "Admin"),
        (ROLE_FINANCE, "Finance Admin"),
        (ROLE_MANAGER, "Property Manager"),
        (ROLE_CUSTOMER, "Customer"),
    ]

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_CUSTOMER)
    mobile = models.CharField(max_length=20, blank=True)

    def __str__(self) -> str:
        return self.get_full_name() or self.username


class Company(TimeStampedModel):
    """Umbrella company for properties."""

    name = models.CharField(max_length=255)
    address = models.TextField(blank=True)

    def __str__(self) -> str:
        return self.name


class CustomerProfile(TimeStampedModel):
    """Customer identity and onboarding state."""

    ID_PAN = "PAN"
    ID_EMIRATES = "EMIRATES_ID"
    ID_VISA = "VISIT_VISA"
    ID_PASSPORT = "PASSPORT"
    ID_CHOICES = [
        (ID_PAN, "PAN Card"),
        (ID_EMIRATES, "Emirates ID"),
        (ID_VISA, "Visit Visa Number"),
        (ID_PASSPORT, "Passport Number"),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    company = models.ForeignKey(Company, on_delete=models.SET_NULL, null=True, blank=True)
    id_type = models.CharField(max_length=20, choices=ID_CHOICES)
    id_number = models.CharField(max_length=100)
    id_document = models.ForeignKey(Document, on_delete=models.SET_NULL, null=True, blank=True)
    address = models.TextField(blank=True)
    joined_date = models.DateField(null=True, blank=True)
    approved = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"{self.user.get_full_name()} ({self.get_id_type_display()})"
