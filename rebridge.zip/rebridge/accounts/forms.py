from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User, CustomerProfile


class SignupForm(UserCreationForm):
    """Customer sign-up form with ID upload."""

    email = forms.EmailField()
    mobile = forms.CharField()
    id_type = forms.ChoiceField(choices=CustomerProfile.ID_CHOICES)
    id_number = forms.CharField()
    address = forms.CharField(widget=forms.Textarea)
    id_document = forms.FileField()

    class Meta:
        model = User
        fields = (
            "username",
            "first_name",
            "last_name",
            "email",
            "mobile",
            "password1",
            "password2",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            css = field.widget.attrs.get("class", "")
            field.widget.attrs["class"] = f"{css} input".strip()
            field.widget.attrs.setdefault("placeholder", name.replace("_", " ").title())


class LoginForm(AuthenticationForm):
    """Login with email/mobile + password."""

    username = forms.CharField(label="Email or Mobile")
    password = forms.CharField(widget=forms.PasswordInput())

    def __init__(self, request=None, *args, **kwargs):
        super().__init__(request, *args, **kwargs)
        for name, field in self.fields.items():
            css = field.widget.attrs.get("class", "")
            field.widget.attrs["class"] = f"{css} input".strip()
            field.widget.attrs.setdefault("placeholder", field.label)
