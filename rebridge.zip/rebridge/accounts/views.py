from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.utils import timezone
from core.models import Document
from core.services.otp import send_email_otp, validate_otp
from core.utils import days_until
from .forms import SignupForm, LoginForm
from .models import User, CustomerProfile
from properties.models import BedAllocation
from finance.models import Renewal


def signup(request):
    """Handle customer sign-up and trigger OTP."""
    if request.method == "POST":
        form = SignupForm(request.POST, request.FILES)
        if form.is_valid():
            user: User = form.save(commit=False)
            user.username = form.cleaned_data["email"]
            user.role = User.ROLE_CUSTOMER
            user.is_active = True
            user.save()
            doc = Document.objects.create(
                file=form.cleaned_data["id_document"],
                uploaded_by=user,
                description="ID Document",
            )
            CustomerProfile.objects.create(
                user=user,
                id_type=form.cleaned_data["id_type"],
                id_number=form.cleaned_data["id_number"],
                id_document=doc,
                address=form.cleaned_data["address"],
                approved=False,
                joined_date=timezone.now().date(),
            )
            send_email_otp(user, user.email)
            messages.success(request, "Account created. Please verify email with OTP.")
            request.session["pending_user_id"] = user.id
            return redirect("accounts:verify")
    else:
        form = SignupForm()
    return render(request, "accounts/signup.html", {"form": form})


def verify(request):
    """Verify OTP for email confirmation."""
    user_id = request.session.get("pending_user_id")
    if not user_id:
        return redirect("accounts:signup")
    user = User.objects.get(id=user_id)
    if request.method == "POST":
        code = request.POST.get("otp")
        if validate_otp(user, code):
            messages.success(request, "Email verified. Await admin approval.")
            return redirect("accounts:login")
        messages.error(request, "Invalid or expired OTP.")
    return render(request, "accounts/verify.html")


def login_view(request):
    """Customer/admin login."""
    if request.method == "POST":
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = authenticate(
                request,
                username=form.cleaned_data["username"],
                password=form.cleaned_data["password"],
            )
            if user:
                if user.is_superuser and user.role != User.ROLE_ADMIN:
                    user.role = User.ROLE_ADMIN
                    user.save(update_fields=["role"])
                login(request, user)
                return redirect(
                    "properties:admin_dashboard"
                    if user.role in [User.ROLE_ADMIN, User.ROLE_FINANCE, User.ROLE_MANAGER]
                    or user.is_staff
                    else "accounts:dashboard"
                )
            messages.error(request, "Invalid credentials.")
    else:
        form = LoginForm()
    return render(request, "accounts/login.html", {"form": form})


@login_required
def dashboard(request):
    """Customer dashboard with renewal + allocation summary."""
    if request.user.role != User.ROLE_CUSTOMER:
        return redirect("properties:admin_dashboard")
    profile = getattr(request.user, "profile", None)
    if not profile:
        messages.error(request, "No customer profile linked to this account.")
        return redirect("accounts:login")
    allocation = BedAllocation.objects.filter(customer=profile, active=True).first()
    renewal = Renewal.objects.filter(customer=profile).order_by("-end_date").first()
    renewal_days = days_until(renewal.end_date) if renewal else None
    return render(
        request,
        "accounts/dashboard.html",
        {
            "profile": profile,
            "allocation": allocation,
            "renewal": renewal,
            "renewal_days": renewal_days,
        },
    )


def logout_view(request):
    """Log out current user."""
    logout(request)
    return redirect("accounts:login")
