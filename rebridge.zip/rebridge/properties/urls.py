from django.urls import path
from . import views

urlpatterns = [
    path("", views.admin_dashboard, name="admin_dashboard"),
    path("properties/", views.property_list, name="property_list"),
    path("properties/<int:pk>/", views.property_detail, name="property_detail"),
    path("allocate/<int:bed_id>/<int:customer_id>/", views.allocate_bed, name="allocate_bed"),
    path("manage/", views.manage_center, name="manage_center"),
]
