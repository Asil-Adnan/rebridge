from django.contrib import admin
from .models import Property, Bed, BedAllocation


@admin.register(Property)
class PropertyAdmin(admin.ModelAdmin):
    list_display = ("name", "company", "area", "total_beds", "created_at")
    search_fields = ("name", "company__name")


@admin.register(Bed)
class BedAdmin(admin.ModelAdmin):
    list_display = ("property", "number", "status")
    list_filter = ("status",)
    search_fields = ("property__name", "number")


@admin.register(BedAllocation)
class BedAllocationAdmin(admin.ModelAdmin):
    list_display = ("bed", "customer", "start_date", "end_date", "active")
    list_filter = ("active",)
