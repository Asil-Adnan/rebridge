from decimal import Decimal
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q, Sum
from django.shortcuts import render, redirect, get_object_or_404
from accounts.models import CustomerProfile
from .models import Property, Bed, BedAllocation
from finance.models import Advance, Expense, Income, LedgerEntry


@login_required
def admin_dashboard(request):
    """Admin dashboard with bed stats."""
    total_beds = Bed.objects.count()
    occupied = Bed.objects.filter(status=Bed.STATUS_OCCUPIED).count()
    available = Bed.objects.filter(status=Bed.STATUS_AVAILABLE).count()
    return render(
        request,
        "properties/admin_dashboard.html",
        {"total_beds": total_beds, "occupied": occupied, "available": available},
    )


@login_required
def property_list(request):
    """List all properties."""
    props = Property.objects.all()
    return render(request, "properties/property_list.html", {"properties": props})


@login_required
def property_detail(request, pk):
    """Show property details with beds and vouchers."""
    prop = get_object_or_404(Property, pk=pk)
    beds = prop.beds.annotate(
        active_allocations=Count("allocations", filter=Q(allocations__active=True))
    )
    advances = prop.advances.order_by("-date")[:6]
    expenses = prop.expenses.order_by("-date")[:10]
    return render(
        request,
        "properties/property_detail.html",
        {"property": prop, "beds": beds, "advances": advances, "expenses": expenses},
    )


@login_required
def allocate_bed(request, bed_id, customer_id):
    """Allocate a bed to a customer."""
    bed = get_object_or_404(Bed, id=bed_id)
    customer = get_object_or_404(CustomerProfile, id=customer_id)
    if request.method == "POST":
        BedAllocation.objects.filter(customer=customer, active=True).update(active=False)
        BedAllocation.objects.create(
            bed=bed, customer=customer, start_date=request.POST["start_date"]
        )
        bed.status = Bed.STATUS_OCCUPIED
        bed.save(update_fields=["status"])
        return redirect("properties:property_detail", pk=bed.property.id)
    return render(
        request, "properties/allocate_bed.html", {"bed": bed, "customer": customer}
    )


@login_required
def manage_center(request):
    """Single pane to manage beds, expenses, income, and advances."""
    properties = Property.objects.all()
    selected_id = request.POST.get("property_id") or request.GET.get("property")
    if not selected_id and properties.exists():
        selected_id = properties.first().id
    prop = Property.objects.filter(id=selected_id).first() if selected_id else None

    if prop and request.method == "POST":
        action = request.POST.get("action")
        try:
            if action == "update_bed":
                bed = get_object_or_404(Bed, id=request.POST.get("bed_id"), property=prop)
                bed.status = request.POST.get("status", bed.status)
                bed.save(update_fields=["status"])
                messages.success(request, f"Updated {bed.number} status to {bed.get_status_display()}.")
            elif action == "add_expense":
                required = ["expense_type", "expense_amount", "expense_date", "expense_voucher", "expense_name"]
                if not all(request.POST.get(f) for f in required):
                    raise ValueError("All expense fields are required.")
                exp = Expense.objects.create(
                    property=prop,
                    transaction_name=request.POST.get("expense_name"),
                    expense_type=request.POST.get("expense_type"),
                    amount=Decimal(request.POST.get("expense_amount")),
                    date=request.POST.get("expense_date"),
                    voucher_id=request.POST.get("expense_voucher"),
                )
                LedgerEntry.objects.create(
                    property=prop,
                    entry_type=LedgerEntry.DEBIT,
                    amount=exp.amount,
                    date=exp.date,
                    source="expense",
                    reference_id=exp.voucher_id,
                    notes=exp.transaction_name,
                )
                messages.success(request, "Expense added.")
            elif action == "add_income":
                required = ["income_amount", "income_date", "income_reference", "income_name"]
                if not all(request.POST.get(f) for f in required):
                    raise ValueError("All income fields are required.")
                inc = Income.objects.create(
                    property=prop,
                    transaction_name=request.POST.get("income_name"),
                    amount=Decimal(request.POST.get("income_amount")),
                    date=request.POST.get("income_date"),
                    reference=request.POST.get("income_reference"),
                )
                LedgerEntry.objects.create(
                    property=prop,
                    entry_type=LedgerEntry.CREDIT,
                    amount=inc.amount,
                    date=inc.date,
                    source="income",
                    reference_id=inc.reference,
                    notes=inc.transaction_name,
                )
                messages.success(request, "Income added.")
            elif action == "add_advance":
                required = ["advance_amount", "advance_date", "advance_voucher", "advance_name"]
                if not all(request.POST.get(f) for f in required):
                    raise ValueError("All advance fields are required.")
                adv = Advance.objects.create(
                    property=prop,
                    transaction_name=request.POST.get("advance_name"),
                    amount=Decimal(request.POST.get("advance_amount")),
                    date=request.POST.get("advance_date"),
                    voucher_ref=request.POST.get("advance_voucher"),
                    notes=request.POST.get("advance_notes") or "",
                )
                LedgerEntry.objects.create(
                    property=prop,
                    entry_type=LedgerEntry.DEBIT,
                    amount=adv.amount,
                    date=adv.date,
                    source="advance",
                    reference_id=adv.voucher_ref,
                    notes=adv.transaction_name,
                )
                messages.success(request, "Advance added.")
            elif action == "property_add":
                Property.objects.create(
                    company=prop.company if prop else properties.first().company,
                    name=request.POST["property_name"],
                    address=request.POST["property_address"],
                    area=request.POST["property_area"],
                    total_beds=int(request.POST["property_beds"]),
                )
                messages.success(request, "Property created.")
            elif action == "property_update":
                prop.name = request.POST["property_name"]
                prop.address = request.POST["property_address"]
                prop.area = request.POST["property_area"]
                prop.total_beds = int(request.POST["property_beds"])
                prop.save()
                messages.success(request, "Property updated.")
            elif action == "property_delete":
                prop.delete()
                messages.success(request, "Property deleted.")
                return redirect("properties:manage_center")
            elif action == "expense_update":
                exp = get_object_or_404(Expense, id=request.POST["expense_id"], property=prop)
                exp.transaction_name = request.POST["expense_name"]
                exp.expense_type = request.POST["expense_type"]
                exp.amount = Decimal(request.POST["expense_amount"])
                exp.date = request.POST["expense_date"]
                exp.voucher_id = request.POST["expense_voucher"]
                exp.save()
                LedgerEntry.objects.filter(source="expense", reference_id=exp.voucher_id, property=prop).update(
                    amount=exp.amount, date=exp.date, notes=exp.transaction_name
                )
                messages.success(request, "Expense updated.")
            elif action == "expense_delete":
                exp = get_object_or_404(Expense, id=request.POST["expense_id"], property=prop)
                LedgerEntry.objects.filter(source="expense", reference_id=exp.voucher_id, property=prop).delete()
                exp.delete()
                messages.success(request, "Expense deleted.")
            elif action == "income_update":
                inc = get_object_or_404(Income, id=request.POST["income_id"], property=prop)
                inc.transaction_name = request.POST["income_name"]
                inc.amount = Decimal(request.POST["income_amount"])
                inc.date = request.POST["income_date"]
                inc.reference = request.POST["income_reference"]
                inc.save()
                LedgerEntry.objects.filter(source="income", reference_id=inc.reference, property=prop).update(
                    amount=inc.amount, date=inc.date, notes=inc.transaction_name
                )
                messages.success(request, "Income updated.")
            elif action == "income_delete":
                inc = get_object_or_404(Income, id=request.POST["income_id"], property=prop)
                LedgerEntry.objects.filter(source="income", reference_id=inc.reference, property=prop).delete()
                inc.delete()
                messages.success(request, "Income deleted.")
            elif action == "advance_update":
                adv = get_object_or_404(Advance, id=request.POST["advance_id"], property=prop)
                adv.transaction_name = request.POST["advance_name"]
                adv.amount = Decimal(request.POST["advance_amount"])
                adv.date = request.POST["advance_date"]
                adv.voucher_ref = request.POST["advance_voucher"]
                adv.notes = request.POST.get("advance_notes", "")
                adv.save()
                LedgerEntry.objects.filter(source="advance", reference_id=adv.voucher_ref, property=prop).update(
                    amount=adv.amount, date=adv.date, notes=adv.transaction_name
                )
                messages.success(request, "Advance updated.")
            elif action == "advance_delete":
                adv = get_object_or_404(Advance, id=request.POST["advance_id"], property=prop)
                LedgerEntry.objects.filter(source="advance", reference_id=adv.voucher_ref, property=prop).delete()
                adv.delete()
                messages.success(request, "Advance deleted.")
        except Exception as exc:  # noqa: BLE001
            messages.error(request, f"Action failed: {exc}")

    context = {
        "properties": properties,
        "property": prop,
        "beds": prop.beds.all() if prop else [],
        "expenses": prop.expenses.order_by("-date")[:10] if prop else [],
        "income": prop.income.order_by("-date")[:10] if prop else [],
        "advances": prop.advances.order_by("-date")[:10] if prop else [],
        "ledger_entries": LedgerEntry.objects.filter(property=prop).order_by("-date", "-created_at")[:30]
        if prop
        else [],
        "ledger_totals": LedgerEntry.objects.filter(property=prop).aggregate(
            debit=Sum("amount", filter=Q(entry_type=LedgerEntry.DEBIT)),
            credit=Sum("amount", filter=Q(entry_type=LedgerEntry.CREDIT)),
        )
        if prop
        else {"debit": 0, "credit": 0},
    }
    return render(request, "properties/manage.html", context)
