from django.db import models
from accounts.models import Company, CustomerProfile
from core.models import TimeStampedModel


class Property(TimeStampedModel):
    """Property master."""

    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    address = models.TextField()
    area = models.CharField(max_length=120, blank=True)
    total_beds = models.PositiveIntegerField()

    def __str__(self) -> str:
        return self.name


class Bed(TimeStampedModel):
    """Individual bed with occupancy state."""

    STATUS_OCCUPIED = "OCCUPIED"
    STATUS_AVAILABLE = "AVAILABLE"
    STATUS_BLOCKED = "BLOCKED"
    STATUS_CHOICES = [
        (STATUS_OCCUPIED, "Occupied"),
        (STATUS_AVAILABLE, "Available"),
        (STATUS_BLOCKED, "Blocked"),
    ]

    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name="beds")
    number = models.CharField(max_length=20)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_AVAILABLE)

    class Meta:
        unique_together = ("property", "number")

    def __str__(self) -> str:
        return f"{self.property.name} - {self.number}"


class BedAllocation(TimeStampedModel):
    """Tracks which customer holds a bed."""

    bed = models.ForeignKey(Bed, on_delete=models.CASCADE, related_name="allocations")
    customer = models.ForeignKey(
        CustomerProfile, on_delete=models.CASCADE, related_name="allocations"
    )
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    active = models.BooleanField(default=True)

    def __str__(self) -> str:
        return f"{self.customer} -> {self.bed}"
