# Property and bed management
