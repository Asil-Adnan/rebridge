from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include(("accounts.urls", "accounts"), namespace="accounts")),
    path("admin-portal/", include(("properties.urls", "properties"), namespace="properties")),
    path("finance/", include(("finance.urls", "finance"), namespace="finance")),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
