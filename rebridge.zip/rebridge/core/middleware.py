from django.shortcuts import redirect
from django.urls import reverse


class RoleRequiredMiddleware:
    """Light role-based gate for admin portal routes."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith("/admin-portal/") and not request.user.is_authenticated:
            return redirect(reverse("accounts:login"))
        return self.get_response(request)
