# Core utilities and shared models
