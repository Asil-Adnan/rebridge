import random
import string
from datetime import timedelta
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from core.models import OTPLog


def generate_otp(length: int = 6) -> str:
    """Generate a numeric OTP code."""
    return "".join(random.choices(string.digits, k=length))


def otp_expiry_minutes() -> int:
    return getattr(settings, "OTP_EXPIRY_MINUTES", 10)


def send_email_otp(user, email: str) -> OTPLog:
    """Generate and send OTP to the provided email."""
    code = generate_otp()
    otp = OTPLog.objects.create(
        user=user,
        email=email,
        code=code,
        expires_at=timezone.now() + timedelta(minutes=otp_expiry_minutes()),
    )
    send_mail("Your Re-Bridge OTP", f"Your code is {code}", None, [email], fail_silently=False)
    return otp


def validate_otp(user, code: str) -> bool:
    """Validate and consume an OTP."""
    now = timezone.now()
    valid = (
        OTPLog.objects.filter(
            user=user, code=code, consumed=False, expires_at__gte=now
        ).first()
    )
    if valid:
        valid.consumed = True
        valid.save(update_fields=["consumed"])
        return True
    return False
