from django.db import models
from django.conf import settings


class TimeStampedModel(models.Model):
    """Abstract base model with created/updated timestamps."""

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class OTPLog(TimeStampedModel):
    """Stores OTP codes for email/mobile verification."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    email = models.EmailField()
    code = models.CharField(max_length=6)
    expires_at = models.DateTimeField()
    consumed = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"OTP for {self.user} ({self.email})"


class Document(TimeStampedModel):
    """Simple uploaded document placeholder."""

    file = models.FileField(upload_to="ids/")
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    description = models.CharField(max_length=255, blank=True)
    encrypted = models.BooleanField(default=False)

    def __str__(self) -> str:
        return self.description or self.file.name
