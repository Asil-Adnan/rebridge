from datetime import date


def days_until(target_date: date) -> int:
    """Return remaining days until the target date (non-negative)."""
    return max((target_date - date.today()).days, 0)


def format_currency(amount: float) -> str:
    """Format number as currency with two decimals."""
    return f"{amount:,.2f}"
